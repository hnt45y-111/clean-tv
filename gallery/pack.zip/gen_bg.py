# Original football-themed backgrounds in each club's colours (no logos, no photos).
# usage: python3 gen_bg.py clubs.json outdir
import json, math, os, random, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

W, H = 1600, 900


def rgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def dark(c, f):
    return tuple(int(v * f) for v in c)


def grad(c1, c2, angle=90):
    y, x = np.mgrid[0:H, 0:W].astype(np.float32)
    a = math.radians(angle)
    t = (x * math.cos(a) + y * math.sin(a))
    t = (t - t.min()) / (t.max() - t.min())
    arr = np.zeros((H, W, 3), np.float32)
    for i in range(3):
        arr[..., i] = c1[i] + (c2[i] - c1[i]) * t
    return Image.fromarray(arr.clip(0, 255).astype(np.uint8))


def radial(base, color, cx, cy, r, strength=1.0):
    y, x = np.mgrid[0:H, 0:W].astype(np.float32)
    d = np.sqrt((x - cx) ** 2 + (y - cy) ** 2) / r
    k = np.clip(1 - d, 0, 1) ** 2 * strength
    arr = np.asarray(base).astype(np.float32)
    for i in range(3):
        arr[..., i] = arr[..., i] * (1 - k) + color[i] * k
    return Image.fromarray(arr.clip(0, 255).astype(np.uint8))


def vignette(img, f=0.55):
    y, x = np.mgrid[0:H, 0:W].astype(np.float32)
    d = np.sqrt(((x - W / 2) / (W / 2)) ** 2 + ((y - H / 2) / (H / 2)) ** 2)
    k = 1 - np.clip(d - 0.55, 0, 1) * f
    arr = np.asarray(img).astype(np.float32) * k[..., None]
    return Image.fromarray(arr.clip(0, 255).astype(np.uint8))


def noise(img, amt=6, seed=0):
    rng = np.random.default_rng(seed)
    arr = np.asarray(img).astype(np.int16) + rng.integers(-amt, amt + 1, (H, W, 1))
    return Image.fromarray(arr.clip(0, 255).astype(np.uint8))


def overlay(img, layer, alpha):
    return Image.blend(img, layer, alpha)


def pitch_lines(d, color, width=6, y0=0, scale=1.0):
    cx, cy = W / 2, H / 2 + y0
    d.rectangle([80, 60 + y0, W - 80, H - 60 + y0], outline=color, width=width)
    d.line([cx, 60 + y0, cx, H - 60 + y0], fill=color, width=width)
    r = 130 * scale
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=color, width=width)
    d.ellipse([cx - 9, cy - 9, cx + 9, cy + 9], fill=color)
    for side in (0, 1):
        x0 = 80 if side == 0 else W - 80
        sgn = 1 if side == 0 else -1
        d.rectangle(sorted([x0, x0 + sgn * 250]) and [min(x0, x0 + sgn * 250), cy - 230, max(x0, x0 + sgn * 250), cy + 230], outline=color, width=width)
        d.rectangle([min(x0, x0 + sgn * 90), cy - 100, max(x0, x0 + sgn * 90), cy + 100], outline=color, width=width)


def ball(d, cx, cy, r, fill, line):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=fill, outline=line, width=max(2, r // 18))
    pts = [(cx + r * 0.42 * math.cos(math.radians(a - 90)), cy + r * 0.42 * math.sin(math.radians(a - 90))) for a in range(0, 360, 72)]
    d.polygon(pts, fill=line)
    for (px, py) in pts:
        ex, ey = cx + (px - cx) * 2.2, cy + (py - cy) * 2.2
        d.line([px, py, ex, ey], fill=line, width=max(2, r // 22))


def styles(c):
    a, b, bg = rgb(c['a']), rgb(c['b']), rgb(c['c'])
    deep = dark(a, 0.35)
    out = []
    rnd = random.Random(c['id'])

    # 1 stadium night lights
    im = grad(bg, deep, 90)
    for x in (260, 800, 1340):
        im = radial(im, mix(a, (255, 255, 255), .55), x, -40, 620, .55)
    d = ImageDraw.Draw(im)
    for i in range(9):
        y = 560 + i * 40
        d.polygon([(0, y), (W, y - 60), (W, y - 30), (0, y + 30)], fill=mix(bg, a, .12 + i * .03))
    out.append(vignette(noise(im, 5, 1)))

    # 2 pitch from above
    im = grad(dark((30, 120, 60), .7), dark((20, 90, 45), .6), 0)
    arr = np.asarray(im).copy()
    for i in range(0, W, 160):
        arr[:, i:i + 80] = (arr[:, i:i + 80] * 1.08).clip(0, 255)
    im = Image.fromarray(arr.astype(np.uint8))
    tint = Image.new('RGB', (W, H), a)
    im = overlay(im, tint, .28)
    d = ImageDraw.Draw(im)
    pitch_lines(d, mix(b, (255, 255, 255), .5), 5)
    out.append(vignette(noise(im, 4, 2), .7))

    # 3 diagonal kit stripes
    im = Image.new('RGB', (W, H), a)
    d = ImageDraw.Draw(im)
    for i in range(-H, W + H, 220):
        d.polygon([(i, 0), (i + 110, 0), (i + 110 - H * .6, H), (i - H * .6, H)], fill=mix(a, b, .35))
    im = overlay(im, grad(dark(a, .55), a, 120), .45)
    out.append(vignette(noise(im, 5, 3)))

    # 4 vertical stripes, sharp
    im = Image.new('RGB', (W, H), dark(a, .85))
    d = ImageDraw.Draw(im)
    for i in range(0, W, 200):
        d.rectangle([i, 0, i + 100, H], fill=mix(dark(a, .85), b, .55))
    im = overlay(im, grad(bg, (0, 0, 0), 90), .35)
    out.append(vignette(noise(im, 4, 4)))

    # 5 light rays
    im = grad(bg, deep, 90)
    ray = Image.new('L', (W, H), 0)
    rd = ImageDraw.Draw(ray)
    for k in range(14):
        ang = math.radians(60 + k * 4.4)
        x2, y2 = W / 2 + math.cos(ang) * 2200, -120 + math.sin(ang) * 2200
        x3, y3 = W / 2 + math.cos(ang + .03) * 2200, -120 + math.sin(ang + .03) * 2200
        rd.polygon([(W / 2, -120), (x2, y2), (x3, y3)], fill=60 + (k % 3) * 25)
    ray = ray.filter(ImageFilter.GaussianBlur(18))
    im = Image.composite(Image.new('RGB', (W, H), mix(a, b, .4)), im, ray)
    out.append(vignette(noise(im, 4, 5)))

    # 6 crowd bokeh
    im = grad(bg, dark(a, .45), 100)
    lay = Image.new('RGB', (W, H), (0, 0, 0))
    ld = ImageDraw.Draw(lay)
    for i in range(160):
        r = rnd.randint(8, 42)
        x, y = rnd.randint(0, W), rnd.randint(0, H)
        col = [a, b, (255, 255, 255)][i % 3]
        ld.ellipse([x - r, y - r, x + r, y + r], fill=mix((0, 0, 0), col, rnd.uniform(.25, .7)))
    lay = lay.filter(ImageFilter.GaussianBlur(9))
    im = Image.fromarray(np.clip(np.asarray(im).astype(np.int16) + np.asarray(lay).astype(np.int16) * .8, 0, 255).astype(np.uint8))
    out.append(vignette(im))

    # 7 goal net
    im = grad(dark(a, .5), bg, 60)
    d = ImageDraw.Draw(im, 'RGBA')
    s = 60
    for row in range(-1, H // s + 2):
        for col in range(-1, W // s + 2):
            x = col * s * 1.5
            y = row * s * 1.73 + (col % 2) * s * .86
            pts = [(x + s * math.cos(math.radians(t)), y + s * math.sin(math.radians(t))) for t in range(0, 360, 60)]
            d.polygon(pts, outline=b + (90,))
    im = radial(im, mix(a, (255, 255, 255), .3), W * .7, H * .35, 700, .5)
    out.append(vignette(noise(im, 4, 7)))

    # 8 big ball with motion trail
    im = grad(bg, deep, 30)
    trail = Image.new('L', (W, H), 0)
    td = ImageDraw.Draw(trail)
    for i in range(30):
        td.ellipse([200 + i * 26, 300 + i * 6, 420 + i * 26, 520 + i * 6], fill=4 + i * 3)
    trail = trail.filter(ImageFilter.GaussianBlur(25))
    im = Image.composite(Image.new('RGB', (W, H), a), im, trail)
    d = ImageDraw.Draw(im)
    ball(d, 1180, 470, 170, (240, 240, 240), (25, 25, 30))
    out.append(vignette(noise(im, 4, 8)))

    # 9 halftone dots
    im = grad(a, dark(a, .3), 135)
    d = ImageDraw.Draw(im)
    for y in range(0, H + 30, 30):
        for x in range(0, W + 30, 30):
            t = (x / W + y / H) / 2
            r = 2 + 10 * t
            d.ellipse([x - r, y - r, x + r, y + r], fill=mix(a, b, .4))
    out.append(vignette(noise(im, 4, 9)))

    # 10 wave flag
    y, x = np.mgrid[0:H, 0:W].astype(np.float32)
    wave = np.sin(x / 140 + y / 260) * .5 + .5
    band = ((np.sin(x / 90 + np.sin(y / 120) * 2) > 0)).astype(np.float32)
    arr = np.zeros((H, W, 3), np.float32)
    for i in range(3):
        arr[..., i] = (a[i] * band + b[i] * (1 - band) * .8 + a[i] * .2 * (1 - band)) * (.55 + .45 * wave)
    out.append(vignette(noise(Image.fromarray(arr.clip(0, 255).astype(np.uint8)), 4, 10)))

    # 11 hex tiles mosaic
    im = Image.new('RGB', (W, H), bg)
    d = ImageDraw.Draw(im)
    s = 46
    for row in range(-1, H // s + 3):
        for col in range(-1, int(W / (s * 1.5)) + 3):
            cx = col * s * 1.5
            cy = row * s * 1.73 + (col % 2) * s * .86
            t = rnd.random()
            fill = mix(bg, a, .25 + .6 * t) if t > .45 else mix(bg, b, .15 * t)
            pts = [(cx + (s - 3) * math.cos(math.radians(q)), cy + (s - 3) * math.sin(math.radians(q))) for q in range(0, 360, 60)]
            d.polygon(pts, fill=fill)
    out.append(vignette(im, .7))

    # 12 spotlight on centre circle
    im = grad(dark((20, 80, 40), .55), bg, 90)
    im = overlay(im, Image.new('RGB', (W, H), a), .25)
    d = ImageDraw.Draw(im)
    pitch_lines(d, mix(b, (255, 255, 255), .35), 4, 40, 1.4)
    im = radial(im, (255, 255, 255), W / 2, H / 2 + 40, 420, .35)
    out.append(vignette(im, .9))

    # 13 sharp angular shards
    im = grad(bg, dark(a, .6), 0)
    d = ImageDraw.Draw(im)
    for i in range(9):
        x = rnd.randint(-200, W)
        w = rnd.randint(120, 380)
        d.polygon([(x, 0), (x + w, 0), (x + w - 500, H), (x - 500, H)], fill=mix(bg, a if i % 2 else b, rnd.uniform(.15, .55)))
    im = im.filter(ImageFilter.GaussianBlur(1))
    out.append(vignette(noise(im, 5, 13)))

    # 14 smoke / flare (match day)
    base = grad(bg, (0, 0, 0), 90)
    sm = np.random.default_rng(14).random((H // 20, W // 20)).astype(np.float32)
    sm = np.asarray(Image.fromarray((sm * 255).astype(np.uint8)).resize((W, H), Image.BICUBIC).filter(ImageFilter.GaussianBlur(40))).astype(np.float32) / 255
    arr = np.asarray(base).astype(np.float32)
    for i in range(3):
        arr[..., i] = arr[..., i] * (1 - sm) + (a[i] * .9) * sm
    im = Image.fromarray(arr.clip(0, 255).astype(np.uint8))
    im = radial(im, mix(a, (255, 200, 120), .5), W * .2, H * .9, 600, .6)
    out.append(vignette(noise(im, 6, 14)))

    # 15 clean premium gradient with thin stripes
    im = grad(dark(a, .9), dark(a, .25), 160)
    d = ImageDraw.Draw(im, 'RGBA')
    for i in range(-H, W, 34):
        d.line([(i, H), (i + H, 0)], fill=b + (26,), width=2)
    im = radial(im, mix(a, (255, 255, 255), .4), W * .8, H * .15, 600, .45)
    out.append(vignette(noise(im, 3, 15)))
    return out


if __name__ == '__main__':
    clubs = json.load(open(sys.argv[1], encoding='utf-8'))
    od = sys.argv[2]
    os.makedirs(od, exist_ok=True)
    only = sys.argv[3] if len(sys.argv) > 3 else None
    for c in clubs:
        if only and c['id'] != only:
            continue
        for i, im in enumerate(styles(c), 1):
            im.save(os.path.join(od, 'bg-%s-%02d.jpg' % (c['id'], i)), quality=80, optimize=True)
        print('ok', c['id'])
